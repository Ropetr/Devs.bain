# devs.brain — Documentação (Fonte de Verdade)

Este diretório é a “memória persistente” do projeto. Agentes e humanos **devem** ler estes arquivos antes de alterar código.

## Como usar
1. **Ideia → Especificação**: registre requisitos em `docs/module_specs/`.
2. **Decisão arquitetural**: registre em `docs/adr/` (ADR numerado).
3. **Mudanças**: sempre via Pull Request, com checklist preenchido.
4. **Log**: toda entrega atualiza `docs/development_log.md`.

## Índice
- Visão e princípios: `docs/vision.md`, `docs/principles.md`
- Arquitetura: `docs/architecture.md`
- Design system: `docs/design_system.md`
- Roadmap e módulos: `docs/module_specs/INDEX.md`
- Decisões: `docs/adr/`
- Log de desenvolvimento: `docs/development_log.md`
