# Design System (tokens e padrões)

> Este arquivo é “lei” para UI. Se precisar mudar, abra ADR + atualize aqui.

## Branding
- Nome do produto: devs.brain
- Tom: profissional, claro, sem excesso de efeitos

## Cores (preencher/ajustar)
- `--color-bg`: #0B0F14
- `--color-surface`: #111827
- `--color-primary`: #3B82F6
- `--color-success`: #22C55E
- `--color-warning`: #F59E0B
- `--color-danger`: #EF4444
- `--color-text`: #E5E7EB
- `--color-muted`: #9CA3AF

## Tipografia
- Base: 14–16px
- Headings: escala 16/18/20/24/32
- Peso: 400/500/600

## Layout
- Grid de páginas: sidebar + header + content
- Espaçamento: 4/8/12/16/24/32
- Bordas: radius 12 (padrão), 16 (cards grandes)

## Componentes obrigatórios (biblioteca interna)
- Button (variants: primary/secondary/ghost/danger)
- Input, Select, DatePicker
- Table (com paginação e filtros)
- Modal/Drawer
- Toast/Alert
- Badge/Status
- EmptyState

## Regras de consistência
1. Não criar novas variações sem documentar aqui.
2. Tabelas sempre com: busca, filtro, paginação e estados (loading/empty/error).
3. Formularios sempre com: validação inline e mensagens claras.
