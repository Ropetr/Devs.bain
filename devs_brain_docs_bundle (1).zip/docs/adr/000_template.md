# ADR-XXX: Título

**Status:** Proposto | Aceito | Rejeitado | Substituído  
**Data:** YYYY-MM-DD

## Contexto
(qual problema estamos resolvendo?)

## Decisão
(o que foi decidido?)

## Alternativas Consideradas
- Alternativa A: prós/contras
- Alternativa B: prós/contras

## Consequências
- Técnicas:
- Produto/UX:
- Operação:

## Referências
- Links internos (docs/module_specs/...)
