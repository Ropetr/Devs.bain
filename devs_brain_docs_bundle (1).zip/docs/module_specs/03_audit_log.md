# 03 — Audit log e trilha de eventos

## Objetivo
Registrar ações críticas e mudanças relevantes para auditoria, suporte e conformidade.

## Personas e permissões
- Admin/Gerente: consulta trilha e exporta evidências
- Auditor/Contabilidade: acesso somente leitura (opcional)

## Fluxo do usuário (alto nível)
1) Usuário executa ação crítica (ex.: aprovar pagamento)
2) Sistema grava evento (antes/depois ou diff)
3) Tela exibe trilha filtrável (data, usuário, módulo, entidade)

## Telas (UI)
- Audit Log (lista + filtros)
- Audit Log (detalhe)
- (Opcional) Exportação CSV/PDF

## Modelo de dados (alto nível)
- AuditEvent(id, tenant_id, user_id, action, entity_type, entity_id, metadata, created_at)
- Correlation/Trace id para ligar eventos a requests/jobs

## Integrações / eventos
- (Opcional) Envio para stack de logs
- Eventos de domínio: payment.approved, invoice.issued

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: log sensível conter dados pessoais. Mitigação: mascaramento e política de retenção.
- Risco: volume alto. Mitigação: indexação e retenção por plano.

## Critérios de aceite (DoD do módulo)
- Toda ação crítica gera audit event
- Tela permite filtrar por usuário/data/módulo
- Exportação (se definida) funciona
- Política de retenção documentada

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
