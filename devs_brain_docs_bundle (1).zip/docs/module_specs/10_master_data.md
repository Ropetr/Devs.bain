# 10 — Cadastros base (clientes, produtos, impostos)

## Objetivo
Centralizar cadastros essenciais para operar estoque, vendas, compras e fiscal.

## Personas e permissões
- Admin: gerencia cadastros globais do tenant
- Operador: consulta e cria itens permitidos

## Fluxo do usuário (alto nível)
1) Criar/editar clientes e fornecedores
2) Criar/editar produtos e categorias
3) Definir tributações/configurações fiscais (nível inicial)
4) Usar cadastros em compras/vendas

## Telas (UI)
- Clientes/Fornecedores (CRUD)
- Produtos (CRUD) + foto/anexos
- Categorias/Marcas/Unidades
- Tabelas auxiliares (condições de pagamento, centros de custo - opcional)

## Modelo de dados (alto nível)
- Customer/Supplier(tenant_id, dados, status)
- Product(tenant_id, sku, nome, unidade, custo, preço, ncm/opcional, ...)
- TaxProfile(tenant_id, regras iniciais)

## Integrações / eventos
- Importação CSV de produtos
- Eventos: product.created, customer.updated

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: cadastros inconsistentes afetam fiscal. Mitigação: validações e obrigatoriedade gradual.
- Risco: duplicidade. Mitigação: chaves únicas (SKU, documento) + busca inteligente.

## Critérios de aceite (DoD do módulo)
- CRUD completo com validações
- Busca/filtro/paginação em listas
- Produtos suportam preço de custo/venda e status
- Importação básica (se definida)

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
