# 00 — Plataforma e padrões

## Objetivo
Estabelecer a base do ERP: padrões de código, estrutura de pastas, pipeline CI/CD, templates de PR/Issues e governança para agentes.

## Personas e permissões
- Admin do sistema: configura ambiente e políticas
- Dev/Agente executor: implementa via PR
- Reviewer (UI/Arquitetura/QA): aprova mudanças

## Fluxo do usuário (alto nível)
1) Criar documentação base (docs/)
2) Configurar PR templates e checks
3) Definir padrões de lint/format/test
4) Definir convenções de branch e versionamento

## Telas (UI)
- Não há telas de negócio; apenas páginas internas (opcional):
  - Página “Status do sistema” (health/versões)
  - Página “Feature flags” (se aplicável)

## Modelo de dados (alto nível)
- Não aplicável (infra/padrões), mas definir:
  - Convenção de `tenant_id`
  - Convenção de `soft_delete` (ex.: `deleted_at`)
  - Convenção de timestamps (`created_at`, `updated_at`)

## Integrações / eventos
- GitHub Actions (CI)
- Cloudflare Deploy
- (Opcional) Provedor de logs/monitoramento

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: agentes alterarem padrões sem perceber. Mitigação: `CLAUDE.md` + checks obrigatórios + PR template.
- Risco: “deploy como teste”. Mitigação: testes e build na CI antes de deploy.

## Critérios de aceite (DoD do módulo)
- Repositório contém docs base e índices
- Templates de PR/Issue criados
- CI roda lint/build/test
- Não existe commit direto na main

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
