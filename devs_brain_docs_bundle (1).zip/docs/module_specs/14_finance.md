# 14 — Financeiro (Caixa, A/P, A/R, conciliação)

## Objetivo
Controlar contas a pagar/receber, fluxo de caixa, centros de custo e conciliação básica.

## Personas e permissões
- Financeiro: lança, aprova e concilia
- Gerente: aprova pagamentos acima do limite
- Auditor/Contabilidade: leitura e exportação

## Fluxo do usuário (alto nível)
1) Contas a pagar: lançar → aprovar → pagar
2) Contas a receber: gerar (vendas) → receber → conciliar
3) Fluxo de caixa: visão diária/mensal
4) Conciliação: importar/extrair e casar lançamentos (fase 2)

## Telas (UI)
- Dashboard financeiro (KPIs)
- Contas a pagar (lista + detalhe + aprovação)
- Contas a receber (lista + baixa)
- Caixa (movimentações)
- Relatório fluxo de caixa

## Modelo de dados (alto nível)
- Payable/Receivable(tenant_id, status, due_date, amount, counterparty)
- Payment/Receipt (baixas)
- CashMovement
- (Opcional) CostCenter/Category

## Integrações / eventos
- Integração com Compras/Vendas
- Importação OFX/CSV (opcional)
- Eventos: payable.approved, payment.completed

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: duplicidade de lançamentos. Mitigação: chaves e validações + conciliação.
- Risco: falta de rastreabilidade. Mitigação: audit log e vínculos (ref_entity).

## Critérios de aceite (DoD do módulo)
- A/P e A/R funcionam end-to-end
- Aprovação respeita permissões
- Fluxo de caixa mostra saldo projetado
- Exportação mínima (CSV)

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
