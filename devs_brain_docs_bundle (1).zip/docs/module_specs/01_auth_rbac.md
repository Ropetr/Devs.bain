# 01 — Autenticação e RBAC

## Objetivo
Permitir login seguro, gestão de usuários e perfis, com permissões por módulo e ação.

## Personas e permissões
- Admin: gerencia usuários, perfis e permissões
- Gerente: aprova ações sensíveis (ex.: descontos altos)
- Operador/Vendedor: acesso limitado ao próprio escopo

## Fluxo do usuário (alto nível)
1) Usuário acessa login
2) Autentica (senha/SSO opcional)
3) Sistema carrega tenant + papéis
4) UI habilita/oculta ações conforme permissão

## Telas (UI)
- Login
- Recuperação de senha
- Usuários (lista + criar/editar)
- Perfis/Permissões (RBAC)
- Minha conta (dados e sessões)

## Modelo de dados (alto nível)
- User(id, tenant_id, name, email, status, ...)
- Role(id, tenant_id, name)
- Permission(code, description)
- RolePermission(role_id, permission_code)
- UserRole(user_id, role_id)
- Session/Token (conforme stack)

## Integrações / eventos
- (Opcional) SSO (OAuth/SAML)
- Eventos: user.created, role.updated, auth.failed

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: permissões insuficientes exporem dados. Mitigação: deny-by-default + revisão de endpoints.
- Risco: vazamento de sessão. Mitigação: expiração, revogação, logs de login.

## Critérios de aceite (DoD do módulo)
- Login funciona e bloqueia acesso sem autenticação
- RBAC aplicado em backend e UI
- Admin consegue criar usuário e atribuir perfil
- Ações sensíveis respeitam permissão (teste)

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
