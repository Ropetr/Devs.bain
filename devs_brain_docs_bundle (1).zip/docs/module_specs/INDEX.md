# Módulos do ERP — Índice

**Data:** 2025-12-27

## Fundacionais (plataforma)
- 00. Plataforma e padrões: `00_platform_foundation.md`
- 01. Autenticação e RBAC: `01_auth_rbac.md`
- 02. Multi-tenancy e isolamentos: `02_multi_tenancy.md`
- 03. Audit log e trilha de eventos: `03_audit_log.md`

## Negócio (core)
- 10. Cadastros base (clientes, produtos, impostos): `10_master_data.md`
- 11. Estoque: `11_inventory.md`
- 12. Compras: `12_purchasing.md`
- 13. Vendas e faturamento: `13_sales_billing.md`
- 14. Financeiro (caixa, A/R, A/P): `14_finance.md`

## Fiscal (Brasil)
- 20. Fiscal Brasil (NF-e/NFS-e/NFC-e e obrigações): `20_fiscal_brazil.md`

## Operação e gestão
- 30. Relatórios e dashboards: `30_reports_dashboards.md`
- 31. Integrações e automações: `31_integrations.md`
- 32. Admin & Configurações: `32_admin_settings.md`

> Observação: módulos fiscais exigem validação de requisitos específicos por UF/município e do provedor escolhido.
