# 12 — Compras

## Objetivo
Gerir cotações, pedidos e recebimentos, integrando com estoque e contas a pagar.

## Personas e permissões
- Comprador: cria pedidos e recebe mercadorias
- Gerente: aprova pedidos acima de limite
- Financeiro: gera contas a pagar

## Fluxo do usuário (alto nível)
1) Criar solicitação/pedido de compra
2) Aprovação (se necessário)
3) Recebimento (total/parcial) → entrada em estoque
4) Gerar contas a pagar (faturas)

## Telas (UI)
- Fornecedores
- Pedido de compra (CRUD + status)
- Recebimento (lançar itens recebidos)
- Histórico por produto/fornecedor

## Modelo de dados (alto nível)
- PurchaseOrder(tenant_id, supplier_id, status, totals)
- PurchaseOrderItem(product_id, qty, cost)
- GoodsReceipt(ref_po_id, status)
- APInvoice (contas a pagar) integrado ao Financeiro

## Integrações / eventos
- Integração com Estoque e Financeiro
- Eventos: po.approved, goods.received

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: recebimento parcial confundir saldos. Mitigação: status e itens por entrega.
- Risco: divergência de custo médio. Mitigação: política documentada (custo médio/último custo).

## Critérios de aceite (DoD do módulo)
- Pedido com status e aprovação
- Recebimento parcial/total atualiza estoque
- Gera conta a pagar vinculada
- Trilhas no audit log para aprovações

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
