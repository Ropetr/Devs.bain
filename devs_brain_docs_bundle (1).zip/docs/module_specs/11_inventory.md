# 11 — Estoque

## Objetivo
Controlar entrada/saída, saldos, locais e movimentações para evitar vendas sem disponibilidade e melhorar reposição.

## Personas e permissões
- Estoquista: movimenta e inventaria
- Vendedor: consulta disponibilidade
- Gerente: aprova ajustes manuais

## Fluxo do usuário (alto nível)
1) Entradas via compra/ajuste
2) Saídas via venda/consumo
3) Transferência entre locais (opcional)
4) Inventário e ajuste com aprovação

## Telas (UI)
- Dashboard de estoque (alertas de baixo saldo)
- Produtos → Aba “Movimentações”
- Movimentar estoque (entrada/saída/ajuste)
- Inventário (contagem e divergências)

## Modelo de dados (alto nível)
- StockLocation(id, tenant_id, name)
- StockBalance(product_id, location_id, qty_on_hand, ...)
- StockMovement(id, tenant_id, type, qty, reason, ref_entity)
- Regras: não permitir saldo negativo (configurável)

## Integrações / eventos
- Integração com Vendas/Compras
- Eventos: stock.moved, stock.low

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: concorrência (duas saídas ao mesmo tempo). Mitigação: transações e lock otimista/pessimista.
- Risco: saldo negativo indevido. Mitigação: validação e auditoria + aprovação de ajuste.

## Critérios de aceite (DoD do módulo)
- Movimentações atualizam saldo corretamente
- Bloqueio/regra de saldo negativo funcionando
- Alertas de estoque baixo
- Inventário gera ajuste com trilha de aprovação

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
