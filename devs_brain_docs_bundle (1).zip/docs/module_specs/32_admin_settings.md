# 32 — Admin & Configurações

## Objetivo
Configurações por tenant, preferências, parâmetros e feature flags para operação SaaS.

## Personas e permissões
- Admin do tenant: configura empresa, preferências e parâmetros
- SuperAdmin (interno): configura planos e limites

## Fluxo do usuário (alto nível)
1) Atualizar dados da empresa
2) Definir preferências (moeda, formato, políticas)
3) Gerenciar usuários e permissões (link com módulo 01)
4) Configurar feature flags (se aplicável)

## Telas (UI)
- Configurações da empresa
- Preferências do sistema
- Feature flags (opcional)
- Plano e limites (interno)

## Modelo de dados (alto nível)
- TenantSettings
- FeatureFlag (tenant_id, key, enabled)
- PlanLimits (interno)

## Integrações / eventos
- Billing (opcional)
- Eventos: settings.updated, plan.changed

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: configurações incoerentes. Mitigação: validações e defaults.
- Risco: alteração sem rastreio. Mitigação: audit log obrigatório.

## Critérios de aceite (DoD do módulo)
- Preferências persistem e afetam UI/fluxos
- Alterações registradas no audit log
- Feature flags controlam funcionalidades (se usadas)

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
