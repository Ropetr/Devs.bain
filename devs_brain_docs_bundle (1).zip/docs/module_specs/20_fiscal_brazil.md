# 20 — Fiscal Brasil (NF-e/NFS-e/NFC-e e obrigações)

## Objetivo
Emitir e gerenciar documentos fiscais no Brasil e armazenar XML/retornos, integrando com vendas e financeiro.

## Personas e permissões
- Fiscal/Contabilidade: configura e emite
- Vendedor: aciona emissão via faturamento (permissão)
- Admin: configura certificados e parâmetros

## Fluxo do usuário (alto nível)
1) Configurar parâmetros fiscais do tenant
2) Faturar venda e solicitar emissão
3) Enviar para provedor/SEFAZ/município
4) Receber retorno (autorizada/rejeitada)
5) Armazenar XML/PDF e permitir reprocesso

## Telas (UI)
- Configurações fiscais (ambiente, série, CFOP, regimes)
- Emissões (lista + status)
- Detalhe de emissão (xml, pdf, erros)
- Reprocessar/corrigir (quando permitido)

## Modelo de dados (alto nível)
- FiscalConfig(tenant_id, parâmetros)
- InvoiceFiscal(tenant_id, ref_sales_invoice, status, xml, protocol, errors)
- Storage de anexos (XML/DANFE)

## Integrações / eventos
- Provedor fiscal (definir)
- Certificado digital (gestão segura)
- Eventos: invoice.submitted, invoice.authorized, invoice.rejected

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: variação por UF/município. Mitigação: escopo por prioridade (começar com 1–2 casos).
- Risco: segurança do certificado. Mitigação: segredo/cripto, rotação e RBAC rígido.
- Risco: inconsistência tributária. Mitigação: regras e validações progressivas + auditoria.

## Critérios de aceite (DoD do módulo)
- Emissão em ambiente homologação funciona end-to-end
- Status e erros são exibidos claramente
- XML armazenado e recuperável
- Reprocesso controlado por permissão

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
