# 13 — Vendas e faturamento

## Objetivo
Registrar propostas/pedidos, emitir documentos de venda e integrar com estoque e contas a receber.

## Personas e permissões
- Vendedor: cria pedidos e aplica descontos limitados
- Gerente: aprova descontos maiores
- Financeiro: acompanha recebíveis

## Fluxo do usuário (alto nível)
1) Criar pedido de venda
2) Validar estoque e preço
3) Aprovar desconto (se necessário)
4) Faturar/emitir documento (fiscal quando aplicável)
5) Gerar contas a receber e baixar pagamento

## Telas (UI)
- Clientes
- Orçamento/Pedido de venda
- Faturamento (gerar documento)
- Recebimentos (atalho para Financeiro)

## Modelo de dados (alto nível)
- SalesOrder(tenant_id, customer_id, status)
- SalesOrderItem(product_id, qty, price, discount)
- ARInvoice/Receivable
- Integração com emissão fiscal (módulo 20)

## Integrações / eventos
- Gateway de pagamento (opcional)
- Eventos: order.created, invoice.issued, payment.received

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: venda sem estoque. Mitigação: validação e reserva (opcional).
- Risco: descontos fora de política. Mitigação: RBAC + trilha de aprovação.

## Critérios de aceite (DoD do módulo)
- Pedido cria e valida estoque
- Descontos respeitam limites e aprovação
- Faturamento gera recebível
- Integração com estoque (saída)

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
