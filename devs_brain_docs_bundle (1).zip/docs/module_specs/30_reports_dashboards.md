# 30 — Relatórios e dashboards

## Objetivo
Fornecer visão executiva e operacional com KPIs e relatórios exportáveis.

## Personas e permissões
- Gerente/Diretor: visão consolidada
- Operação: relatórios de rotina
- Contabilidade: exportações

## Fluxo do usuário (alto nível)
1) Acessar dashboard
2) Filtrar por período/unidade
3) Exportar relatórios
4) Salvar filtros (opcional)

## Telas (UI)
- Dashboard principal
- Relatório de vendas
- Relatório de estoque (giro/ruptura)
- Relatório financeiro (A/P, A/R, caixa)
- Exportações CSV/PDF

## Modelo de dados (alto nível)
- Views/Materialized views (se necessário)
- ReportDefinition (opcional)

## Integrações / eventos
- (Opcional) BI externo via API
- Eventos: report.exported

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: lentidão em grandes volumes. Mitigação: agregações e índices.
- Risco: divergência de números. Mitigação: “fonte de verdade” por métrica documentada.

## Critérios de aceite (DoD do módulo)
- KPIs principais exibidos
- Filtros por período funcionam
- Exportação CSV mínima disponível
- Métricas documentadas

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
