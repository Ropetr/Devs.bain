# 02 — Multi-tenancy e isolamentos

## Objetivo
Garantir isolamento total de dados por empresa (tenant) para operação SaaS comercializável.

## Personas e permissões
- SuperAdmin (interno): cria tenants e configura planos
- Admin do tenant: gerencia a própria empresa
- Usuários do tenant: acessam apenas seu tenant

## Fluxo do usuário (alto nível)
1) SuperAdmin cria tenant
2) Admin do tenant entra e configura dados básicos
3) Todo dado de negócio carrega tenant_id
4) Consultas e rotinas nunca misturam tenants

## Telas (UI)
- (Interno) Tenants (criar/listar)
- (Tenant) Configurações da empresa (dados, logo, preferências)

## Modelo de dados (alto nível)
- Tenant(id, name, plan, status, ...)
- Todas entidades de negócio: tenant_id obrigatório
- (Opcional) Partitioning/Row-Level Security (dependendo do stack)

## Integrações / eventos
- Billing (opcional) para planos
- Eventos: tenant.created, tenant.suspended

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: query sem tenant_id. Mitigação: middleware obrigatório + testes + revisão de repositórios.
- Risco: job assíncrono misturar tenant. Mitigação: payload sempre com tenant_id + idempotência.

## Critérios de aceite (DoD do módulo)
- Não há endpoint que retorne dados de outro tenant
- Testes garantem enforcement de tenant em rotas críticas
- Jobs carregam tenant_id e respeitam escopo

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
