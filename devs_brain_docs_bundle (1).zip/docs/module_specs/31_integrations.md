# 31 — Integrações e automações

## Objetivo
Permitir conectar serviços externos (pagamentos, marketplaces, contabilidade) e automatizar fluxos via webhooks.

## Personas e permissões
- Admin: configura integrações
- Operação: usa automações
- Suporte: monitora falhas

## Fluxo do usuário (alto nível)
1) Configurar integração (credenciais)
2) Habilitar eventos/webhooks
3) Executar rotinas (sync/import/export)
4) Monitorar logs e reprocessar

## Telas (UI)
- Catálogo de integrações (lista)
- Configurar integração (form)
- Logs de integração (status, erro, retry)
- Reprocessar eventos

## Modelo de dados (alto nível)
- IntegrationConfig(tenant_id, type, secrets_ref, status)
- IntegrationJob(id, status, attempts, last_error)
- WebhookSubscription

## Integrações / eventos
- Webhooks (entrada/saída)
- Filas/Jobs
- Eventos: integration.failed, integration.recovered

## Requisitos não-funcionais
- Performance: operações críticas em até X ms (definir por tela)
- Segurança: RBAC + isolamento por tenant
- Auditoria: eventos relevantes registrados
- Confiabilidade: idempotência em rotinas críticas (pagamentos/fiscal)

## Observabilidade
- Logs estruturados (com tenant_id, user_id, correlation_id)
- Métricas mínimas (erros, latência, volume)
- Alertas para falhas de integrações

## Riscos e mitigação
- Risco: loops e custo. Mitigação: limites de retry, backoff e max attempts.
- Risco: credenciais expostas. Mitigação: secrets manager + RBAC + masking.

## Critérios de aceite (DoD do módulo)
- Integração “exemplo” funcionando (1 conector)
- Logs com retry e status
- Webhook assinado/validado (se aplicável)
- Página de monitoramento

## Testes mínimos
- Unit: regras críticas (cálculos/validações)
- Integration: endpoints principais
- E2E: fluxo “feliz” do usuário + 1 cenário de erro

## Dependências
- Lista de módulos/pré-requisitos

## ADRs relacionados
- (criar/atualizar ADR quando houver decisão estrutural)
