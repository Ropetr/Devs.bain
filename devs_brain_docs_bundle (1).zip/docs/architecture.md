# Arquitetura do Sistema (alto nível)

**Data:** 2025-12-27

## Componentes
- **Frontend**: SPA/SSR (definir stack atual do repositório)
- **Backend/API**: serviços com camadas (Controllers → Services → Repos)
- **Banco de Dados**: PostgreSQL (recomendado para ERP)
- **Fila/Jobs**: para rotinas (importações, emissão fiscal, conciliação)
- **Armazenamento**: arquivos (notas, anexos, imagens)
- **Observabilidade**: logs, métricas e rastreamento

## Multi-tenancy (modelo recomendado)
- Identificador `tenant_id` obrigatório em entidades de negócio.
- Enforcement no nível de aplicação e, quando possível, no nível do banco.
- Políticas de acesso combinando `tenant_id` + `roles/permissions`.

## Padrão de camadas
- `domain/` (regras de negócio)
- `data/` (persistência)
- `api/` (controllers/handlers)
- `ui/` (componentes e páginas)
- `docs/` (fonte de verdade)

## Integrações (alto nível)
- Emissão fiscal (provedor/SEFAZ/municípios via serviço)
- Pagamentos/boletos (gateway)
- Webhooks (eventos de negócio)
- Importação de produtos/estoque (CSV/API)

## Segurança (mínimo)
- Autenticação (tokens/sessão)
- RBAC + permissões por módulo
- Auditoria de ações relevantes
- Rate limiting e proteção contra abuso
