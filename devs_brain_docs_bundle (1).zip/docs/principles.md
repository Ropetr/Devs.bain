# Princípios e Regras do Produto

## Princípios de Engenharia
1. **Multi-tenant desde o dia 1**: nenhuma tabela “global” sem justificativa.
2. **Auditabilidade**: ações relevantes geram eventos e trilha (audit log).
3. **Soft delete**: não apagar dados críticos; usar status/arquivamento.
4. **Evolução segura**: mudanças de schema com migração e ADR.
5. **Observabilidade**: logs estruturados e métricas mínimas por módulo.

## Princípios de UX
1. Consistência (mesmos componentes e padrões visuais).
2. Foco em fluxo (reduzir cliques; orientar com validações).
3. Legibilidade (contraste, hierarquia, espaçamento).
4. “Erros ensináveis” (mensagens claras e ações sugeridas).

## Critérios de qualidade (DoD)
- Testes mínimos do fluxo crítico
- Checklist de PR completo
- Atualização de documentação (módulo + log)
- Nenhuma regressão visual (UI)
- Deploy verde (build/test passando)
