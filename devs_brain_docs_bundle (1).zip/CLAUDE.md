# CLAUDE.md — Guardrails do projeto devs.brain

## Regras inegociáveis
1) Nunca fazer commit direto na `main`. Sempre abrir Pull Request.
2) Antes de alterar UI, ler `docs/design_system.md`.
3) Antes de alterar dados/DB/arquitetura, criar/atualizar ADR em `docs/adr/`.
4) Toda entrega atualiza `docs/development_log.md` e o spec do módulo em `docs/module_specs/`.
5) Não remover funcionalidades existentes sem registrar impacto e plano de migração.

## Processo de trabalho (obrigatório)
Para cada tarefa:
A) Proposta do Arquiteto (impactos e dependências)
B) Revisão UI/UX (conformidade com design system)
C) Plano de QA (testes e cenários)
D) Execução em PR com checklist

## Definição de pronto
- CI verde (lint/build/test)
- Checklist de PR completo
- Documentação atualizada
