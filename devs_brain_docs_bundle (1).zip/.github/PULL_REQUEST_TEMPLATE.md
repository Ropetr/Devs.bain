## Objetivo
Descreva o que este PR entrega (1–3 frases).

## Checklist (obrigatório)
- [ ] Li/considerei `CLAUDE.md` e os arquivos relevantes em `/docs`
- [ ] UI segue `docs/design_system.md` (sem novas cores/variações não documentadas)
- [ ] Se houve mudança arquitetural, criei/atualizei um ADR em `docs/adr/`
- [ ] Atualizei `docs/development_log.md`
- [ ] Testes: unit/integration/e2e conforme o módulo
- [ ] CI verde (lint/build/test)
- [ ] Sem commit direto na main (apenas PR)

## Evidências
- Prints / passos de teste / logs relevantes

## Riscos / Mitigações
- Liste riscos e como mitigou
