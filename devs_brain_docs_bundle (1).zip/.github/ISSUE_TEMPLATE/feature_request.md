---
name: Feature Request
about: Criar uma funcionalidade nova com requisitos claros
title: "[Feature] "
labels: ["feature"]
---

## Objetivo do módulo/feature
(qual problema resolve?)

## Fluxo do usuário
1)
2)
3)

## Campos e validações
- Campo:
- Regra:

## Permissões (RBAC)
- Quem pode ver?
- Quem pode editar?
- Quem aprova?

## Critérios de aceite
- [ ]
- [ ]
- [ ]

## Observações
- Dependências:
- Riscos:
